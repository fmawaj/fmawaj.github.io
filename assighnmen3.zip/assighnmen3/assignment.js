const bugEl=document.getElementById("target");
console.log('Play well' , score);


let scoreEl = document.getElementById("score")
let Score = 0;
let resetscoreBtn= document.getElementById("resetScore");

scoreEl.innerHTML = "Score: " + score;

bugEl.addEventListener("click", ()=>{
    score++;
    scoreEl.innerHTML = "Score: " + score;
    if(score ===5){
    }
});
var canvas = document.createElement("canvas");
var ctx = canvas.getContext("2d");
canvas.width = 720;
canvas.height =550;
document.getElementById("theCanvas").appendChild(canvas);


var bgReady = false;
var bgImage = new Image();
bgImage.onload = function () {
    bgReady = true;
};
bgImage.src = "images/background.png.png";


var bugReady = false;
var bugImage = new Image();
bugImage.onload = function () {
    bugReady = true;
};
bugImage.src = "images/bug.pnd.png";

// initialize hop interval to 2 seconds
var hopInterval = 1000;

var hop = setInterval(function () {
    resetLocation();
}, hopInterval);

var bug = {
    speed: 100 
};


var resetLocation = function () {
    
    bug.x = 20 + (Math.random() * (canvas.width - 50));
    bug.y = 20 + (Math.random() * (canvas.height - 50));
};

// initialize score to 0
var score = 0;



// Reset hopping interval
var resetSpeed = function () {
    clearInterval(hop);
    hopInterval = 2000;
    hop = setInterval(function () {
        resetLocation();
    }, hopInterval);
};
var resetScore = function () {
    score = 0;
    // reset the speed
    resetSpeed();
};


var render = function () {
    if (bgReady) {
        ctx.drawImage(bgImage, 0, 0);
    }

    if (bugReady) {
        ctx.drawImage(bugImage, bug.x, bug.y);
    }

    
    ctx.fillStyle = "rgb(0, 0, 250/)";
    ctx.font = "14px Helvetica";
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    document.getElementById("score").innerHTML = "Score : " + score;
};

var main = function () {
    render();

   
    requestAnimationFrame(main);
};

main();


