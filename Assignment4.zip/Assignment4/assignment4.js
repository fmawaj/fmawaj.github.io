


"use strict";

window.addEventListener("load", createCard);

let counter =0;

function createCard() {

  fetch("products.json")

    .then(response => response.json())
    .then(json => {

      let container = document.getElementById('container');
      let delay = 1000;

      for (let product of json.products) {

       
        setTimeout(() => {

          let card = document.createElement('div');
          card.className = 'product card';

          let img = document.createElement('img');
          img.src = product.src;
          img.alt = product.alt;

          card.appendChild(img);
          let title = document.createElement('h2');
          title.innerHTML = product.title;
          card.appendChild(title);

          let description = document.createElement('p');
          description.innerHTML = product.description;
          card.appendChild(description);

          let price = document.createElement('p');
          price.className = 'product-price';
          price.innerHTML = '$' + product.price;
          card.appendChild(price);

          let color = document.createElement('p');
          color.innerHTML = 'Color: ' + product.color;
          card.appendChild(color);
          container.appendChild(card);

        } , delay * ++counter);

      }

      
      move();

    });
}

// progess Bar 


function move () {

  if (counter == json.product.length) {

    let progressBar = document.getElementById("progressbar");
    progressBar.style.display = "block";
    progressBar.style.width = width + "%";

      }
    }
  